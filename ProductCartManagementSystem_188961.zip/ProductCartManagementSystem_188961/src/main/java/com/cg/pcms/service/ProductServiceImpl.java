package com.cg.pcms.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.pcms.dao.ProductRepository;
import com.cg.pcms.dto.Product;

@Service
@Transactional
public class ProductServiceImpl implements IProductService{
	
	@Autowired
	ProductRepository prd;
	
	@Override
	public ArrayList<Product> ViewProducts() {
		// TODO Auto-generated method stub
		return prd.ViewProducts();
	}

}
