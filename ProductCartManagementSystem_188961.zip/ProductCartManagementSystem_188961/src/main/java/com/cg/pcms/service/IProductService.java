package com.cg.pcms.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.cg.pcms.dto.Product;

@Service
public interface IProductService {
	public ArrayList<Product> ViewProducts();

}
