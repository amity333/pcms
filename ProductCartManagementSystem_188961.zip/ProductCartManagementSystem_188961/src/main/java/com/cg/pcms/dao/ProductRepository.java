package com.cg.pcms.dao;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.pcms.dto.Product;




public interface ProductRepository extends JpaRepository<Product,String> {
	@Query("SELECT productList FROM Product productList")
	public ArrayList<Product> ViewProducts();

}
