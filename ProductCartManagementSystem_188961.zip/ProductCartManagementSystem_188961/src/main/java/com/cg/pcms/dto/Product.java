package com.cg.pcms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="product")
public class Product {
	@NotEmpty(message="product id is  Mandatory")
	@Id
	@Column(name="id",length=20)
	private String productId;
	
	@NotEmpty(message="Product Name is mandatory")
	@Column(name="name",length=20)
	private String productName;
	
	@NotEmpty(message="Product model is mandatory")
	@Column(name="model",length=20)
	private String productModel;
	
	@NotEmpty(message="Product Price is mandatory")
	@Column(name="price")
	private int productPrice;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public Product(@NotEmpty(message = "product id is  Mandatory") String productId,
			@NotEmpty(message = "Product Name is mandatory") String productName,
			@NotEmpty(message = "Product model is mandatory") String productModel,
			@NotEmpty(message = "Product Price is mandatory") int productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productModel = productModel;
		this.productPrice = productPrice;
	}
	
	public Product() {}

	@Override
	public String toString() {
		return "product [productId=" + productId + ", productName=" + productName + ", productModel=" + productModel
				+ ", productPrice=" + productPrice + "]";
	};
	
	

}
